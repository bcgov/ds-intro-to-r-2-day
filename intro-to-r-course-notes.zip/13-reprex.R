#########  Seeking Help from Others with reprex #########
## Help People Help You - reprex
## --------------------------------------------------------------------- 




# install.packages("reprex")
# load libraries we need
# read in data
# munge data and make bar plot
# error in syntax - this does not work
# use dput to make data set with code
# error in syntax - this does not work
# ?datasets # built in datasets
# ?starwars # ships with dplyr
# View(starwars)
# error in syntax - this does not work
## Other Helpful Resources
## --------------------------------------------------------------------- 




